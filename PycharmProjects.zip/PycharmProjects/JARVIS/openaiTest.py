import openai
from config import apiKey  # Assuming apiKey is defined in config.py

# Set your OpenAI API key
openai.api_key = apiKey

# Specify the prompt for the completion
prompt = "Translate the following English text to French:"

# Generate a completion using the GPT-3.5-turbo model
response = openai.Completion.create(
    engine="gpt-3.5-turbo",
    prompt=prompt,
    temperature=0.7,
    max_tokens=150
)

# Print the generated completion
print(response.choices[0].text.strip())
