import speech_recognition as sr
import os
import webbrowser
import datetime
import wikipedia
import smtplib
import random
from newsapi import NewsApiClient
import subprocess
import base64



# $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$  SEND EMAIL FUNCTION $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
def sendEmail(to,content):
    server=smtplib.SMTP('smtp.gmail.com',587)
    server.ehlo()
    server.starttls()
    server.login("khanseoleads@gmail.com","qoer gvry ehkp tglh")
    server.sendmail("khanseoleads@gmail.com",to,content)
    server.close()
#say function
def say(text):
    # os.system(f"powershell -command \"Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak('{text}')\"")
    # sanitized_text = text.replace("'", '\\"')

    # Use PowerShell to speak the text
    # os.system(
        # f'powershell -command "Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak(\\"{sanitized_text}\\")"')

    encoded_text = base64.b64encode(text.encode("utf-8")).decode("utf-8")

    # Construct the PowerShell command to decode and speak the text
    powershell_command = f"$text = '{encoded_text}'; $decodedText = [System.Text.Encoding]::UTF8.GetString([System.Convert]::FromBase64String($text)); Add-Type -AssemblyName System.Speech; (New-Object System.Speech.Synthesis.SpeechSynthesizer).Speak($decodedText)"

    # Use subprocess to run PowerShell command
    subprocess.run(["powershell", "-Command", powershell_command], check=True)


# @@@@@@@@@@ This function takes Command from user @@@@@@@@@@@@@
def takeCommand():
    r =sr.Recognizer()  #Recognizer is predefined class
    with sr.Microphone() as source:           #Microphone is predefined class
        r.pause_threshold = 1
        audio=r.listen(source)                # listen is built in funciton

        try:                                  #we use try catch to catch the problem when there is problem occur in listening
            query = r.recognize_google(audio,language='en-in')
            print(f"User said {query}")
            query = query.replace('"', "'").replace('“', "'").replace('”', "'").replace('‘', "'").replace('’', "'")
            return query
        except Exception as e:
             return "Some Error Occured Sorry From the JARVIS"


if __name__ == '__main__':

    print('PyCharm')
    say("Hello I am JARVIS AI Tell me how I may assist you:")
    while True:
        print("Listening...")
        query = takeCommand()
        # say(query)
        #Pending
        sites = [["YouTube","https://www.youtube.com"],['Google',"https://www.google.com"],["Discovery Voice","https://www.discoveryvoice.com"],["Wikipedia","https://www.wikipedia.com"],['Amazon','https://www.amazon.com'],['Portal','https://lms.aust.edu.pk'],["AUST Website",'https://aust.edu.pk'],['Twitter','https://twitter.com'],['Instagram','https://www.instagram.com'],['FaceBook','https://facebook.com'],['Tiktok','https://tiktok.com'],['Stack OverFlow','https://stackoverflow.com'],['GitHub','https://github.com'],['Code With Harry','https://www.youtube.com/@CodeWithHarry'],['My Fibre Profile','https://fiverr.com/ahmad65185']]
        try:
            for site in sites:

                if f"Open {site[0]}".lower() in query.lower():
                    say(f"Opening {site[0]} Please wait sir!")
                    webbrowser.open(site[1])
        except Exception as e:
                 say("Sorry this site is not found:")

                #Pending
        if f"Play Music".lower() in query.lower():
             musicPath=f"C:/Users/HP/Downloads/Moye-Moye(PaglaSongs).mp3"
             os.startfile(musicPath)

        if f"Open VS CODE".lower() in query.lower():
            vsPath=f"C:/Users/HP/AppData/Local/Programs/Microsoft VS Code/Code.exe"
            os.startfile(vsPath)

        if f"Open Word".lower() in query.lower():
             wordPath=f"C:/Program Files (x86)/Microsoft Office/Office14/WINWORD.EXE"
             os.startfile(wordPath)
        if f"Open EXCEL".lower() in query.lower():
             wordPath=f"C:/Program Files (x86)/Microsoft Office/Office14/EXCEL.EXE"
             os.startfile(wordPath)
        if f"Open POWERPOINT".lower() in query.lower():
             wordPath=f"C:/Program Files (x86)/Microsoft Office/Office14/POWERPNT.EXE"
             os.startfile(wordPath)
        # The time is going on
        if f"The Time".lower() in query.lower():
            hour=datetime.datetime.now().strftime("%H")
            mint=datetime.datetime.now().strftime( "%M")
            say(f"Sir The Time is: {hour} baajj kay {mint}")

#Searching Wikipedia

        if f"Wikipedia".lower() in query.lower():
            try:
                say("Searching Wikipedia....")
                query=query.replace('wikipedia','')
                results = wikipedia.summary(query, sentences=3)
                say(f"According to wikipedia")
                say(results)
            except Exception as e:
                say("Not found in wikipedia")

        if f"Email to Ahmed".lower() in query.lower():
            try:
                say("What should I say")
                content = takeCommand()
                to="brother123hamza@gmail.com"
                sendEmail(to,content)
                say("Email has been sent sucessfully")

            except Exception as e:
                print(e)
                say("Sorry From Jarvis I am unable to send this email")

        if f"Play any".lower() in query.lower():
             musicDir=  'C:/Users/HP/PycharmProjects/Music'
             songs=os.listdir(musicDir)
             random_number = random.randint(0, 3)

             print(random_number)
             os.startfile(os.path.join(musicDir,songs[random_number]))

        if "Tell me the latest news".lower() in query.lower():

            # @@@@@@@@@@@@@@@@@@@@@@@@@@@@ News Integration function @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
            try:
                def get_news(api_key):
                    newsapi = NewsApiClient(api_key=api_key)
                    top_headlines = newsapi.get_top_headlines(country='us')
                    articles = top_headlines['articles']

                    for article in articles:

                        title = article['title']
                        description = article['description']
                        say(f"Title")
                        say(title)
                        say("Description")
                        say(description)


            # Replace 'YOUR_API_KEY' with your actual API key
                api_key = '8c9b6e7bccbd44adbfa9e695e6973e24'
                get_news(api_key)
            except Exception as e:
                say("Sorry I am unable to get more updates")

        else:
            say("Sorry This Command is not defined")

# # Example usage:








# See PyCharm help at https://www.jetbrains.com/help/pycharm/
